/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.phoenixairline.models;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author dell
 */
public class FlightDao {
    
    Connection con=ConnectToDB.createConnection();
    
     public String InsertFlightDetails(Flight flightBean){
         System.out.println("beforeConnection");
       
       int flight_id=flightBean.getFlight_id();
       String gate=flightBean.getGate();
       String takeoff_airport=flightBean.getTakeoff_airport();
       String takeoff_time=flightBean.getTakeoff_time();
       String takeoff_date=flightBean.getTakeoff_date();
       String landing_airport=flightBean.getLanding_airport();
       String landing_time=flightBean.getLanding_time();
       String landing_date=flightBean.getLanding_date();
       
       String InsertQuery="INSERT INTO flights(gate, takeoff_airport, takeoff_time, takeoff_date, landing_airport, landing_time , landing_date) VALUES (?,?,?,?,?,?,?)";
       int i=0;
       
         try {
             System.out.println("beforePrepareST");
             PreparedStatement pstm=con.prepareStatement(InsertQuery);
             //pstm.setInt(flight_id, 1);
             pstm.setString(1, gate);
             pstm.setString(2, takeoff_airport);
             pstm.setString(3, takeoff_time);
             pstm.setString(4, takeoff_date);
             pstm.setString(5, landing_airport);
             pstm.setString(6, landing_time);
             pstm.setString(7, landing_date);
             
             
             i=pstm.executeUpdate();
             System.out.println("after");
             con.close();
         } catch (SQLException ex) {
             
         }
         
         if(i!=0){
             return "Flight details inserted successfully";
     }else{
             return "Flight deatails not inserted";
         }
}
}
